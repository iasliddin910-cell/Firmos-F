"use client";

import React, { useMemo, useState } from "react";
import { CalmBackdrop } from "@/components/calm/CalmBackdrop";
import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";
import type { Role } from "@firmos/shared";
import { setAuthLocal } from "@/lib/auth";
import { useRouter } from "next/navigation";

const ROLES: Role[] = ["OWNER", "ADMIN", "OPERATOR", "ANALYST"];

export default function LoginPage() {
  const router = useRouter();
  const [role, setRole] = useState<Role>("OWNER");
  const [actorId, setActorId] = useState("user-1");
  const [orgId, setOrgId] = useState("default-org");

  const canLogin = useMemo(() => role && actorId.trim().length > 0 && orgId.trim().length > 0, [role, actorId, orgId]);

  function login() {
    if (!canLogin) return;
    setAuthLocal(role, actorId.trim(), orgId.trim());
    router.push("/dashboard/overview");
  }

  return (
    <div className="min-h-screen px-4 py-10">
      <CalmBackdrop />
      <div className="mx-auto max-w-5xl">
        <motion.div
          className="mb-8 flex items-center justify-between"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.35 }}
        >
          <div>
            <div className="text-3xl font-semibold">Firmos</div>
            <div className="muted mt-1 text-sm">
              To‘liq nazorat qilinadigan avtonom agentlar. Qaror — doim sizda.
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Badge tone="ok">Calm UI</Badge>
            <Badge tone="ok">Animations</Badge>
            <Badge tone="ok">3D</Badge>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          <Card className="p-6">
            <CardHeader>
              <div>
                <CardTitle>Kirish</CardTitle>
                <CardDescription>Demo auth (localStorage). Keyin real auth qo‘shiladi.</CardDescription>
              </div>
            </CardHeader>

            <div className="grid gap-3">
              <label className="text-sm font-medium">Role</label>
              <div className="flex flex-wrap gap-2">
                {ROLES.map((r) => (
                  <button
                    key={r}
                    onClick={() => setRole(r)}
                    className={
                      "rounded-full border px-3 py-1.5 text-sm transition " +
                      (role === r ? "bg-slate-900 text-white border-slate-900" : "bg-white/60 border-slate-200 hover:bg-white/80")
                    }
                  >
                    {r}
                  </button>
                ))}
              </div>

              <label className="text-sm font-medium mt-2">Actor ID</label>
              <Input value={actorId} onChange={(e) => setActorId(e.target.value)} placeholder="user-1" />

              <label className="text-sm font-medium mt-2">Org ID</label>
              <Input value={orgId} onChange={(e) => setOrgId(e.target.value)} placeholder="default-org" />

              <div className="mt-2 flex items-center gap-2">
                <Button onClick={login} disabled={!canLogin}>
                  Dashboard’ga kirish
                </Button>
                <Button variant="secondary" onClick={() => router.push("/dashboard/overview")}>
                  Skip
                </Button>
              </div>

              <div className="rounded-xl border border-slate-200 bg-white/50 p-3 text-xs muted mt-2">
                API chaqiriqlarida avtomatik header yuboriladi:
                <div className="mt-1 font-mono text-[11px]">
                  x-role: {role} • x-actor-id: {actorId} • x-org-id: {orgId}
                </div>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <CardHeader>
              <div>
                <CardTitle>Master Protocol</CardTitle>
                <CardDescription>“Konstitutsiya”: agentlar hech qachon sizsiz implement qilmaydi.</CardDescription>
              </div>
            </CardHeader>

            <div className="grid gap-3 text-sm">
              <div className="glass rounded-2xl p-4">
                <div className="font-semibold">Qat’iy taqiqlar</div>
                <ul className="mt-2 list-disc pl-5 muted">
                  <li>Agent avtomatik o‘zgartirish kiritmaydi</li>
                  <li>Agent qaror qabul qilmaydi</li>
                  <li>Agent qonunga zid yo‘l taklif qilmaydi</li>
                </ul>
              </div>

              <div className="glass rounded-2xl p-4">
                <div className="font-semibold">Majburiy zanjir</div>
                <ul className="mt-2 list-disc pl-5 muted">
                  <li>Simulyatsiya</li>
                  <li>Pilot (cheklangan sinov)</li>
                  <li>Real natija</li>
                  <li>Inson tasdig‘i</li>
                </ul>
              </div>

              <div className="text-xs muted">
                Bu UI advanced: animatsiya + “calm glass” dizayn. Og‘ir 3D emas — telefon/CPU’ni qiynamaydi.
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
