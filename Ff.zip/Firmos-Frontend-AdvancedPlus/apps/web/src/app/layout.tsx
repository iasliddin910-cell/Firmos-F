import "./globals.css";
import type { Metadata } from "next";
import { Providers } from "@/components/providers";

export const metadata: Metadata = {
  title: "Firmos",
  description: "Autonomous business agents — calm, transparent, and controllable."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="uz">
      <body className="calm-noise">
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
