"use client";

import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Page } from "@/components/Page";
import { apiGet } from "@/lib/api";
import { Tabs } from "@/components/ui/tabs";
import { KpiCard } from "@/components/blocks/KpiCard";
import { Section } from "@/components/blocks/Section";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, Td, Th } from "@/components/blocks/Table";
import { moneyUZS } from "@/lib/format";

export default function MarketingPage() {
  const [tab, setTab] = useState<"loss" | "profit">("loss");

  const q = useQuery({
    queryKey: ["marketing", "summary"],
    queryFn: async () => apiGet("/api/v1/agents/marketing/insights/summary")
  });

  const data = q.data || {};
  const kpis = data.kpis || {};
  const campaigns = data.campaigns || [];
  const audiences = data.audiences || [];

  return (
    <Page title="Marketing Agent">
      <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
        <KpiCard title="Haqiqiy ROI (7d)" value={`${(kpis.roi_7d ?? 0).toFixed(0)}%`} sub="Foyda/xarajat" tone={(kpis.roi_7d ?? 0) >= 0 ? "ok" : "high"} />
        <KpiCard title="Zararli kampaniyalar" value={String(kpis.harmful_campaigns ?? 0)} sub="Klik bor, sotuv yo‘q" tone="high" />
        <KpiCard title="Ad fatigue" value={`${(kpis.ad_fatigue ?? 0).toFixed(0)}%`} sub="CTR tushishi / conv pasayishi" tone="med" />
      </div>

      <div className="mt-4">
        <Tabs
          value={tab}
          onChange={(v) => setTab(v as any)}
          tabs={[
            { key: "loss", label: "Loss (waste & fake)" },
            { key: "profit", label: "Profit (paying audience)" }
          ]}
        />
      </div>

      {tab === "loss" ? (
        <>
          <Section title="Kampaniyalar" subtitle="Klik → lead → real foyda">
            <Card className="p-4">
              <Table>
                <thead>
                  <tr>
                    <Th>Campaign</Th>
                    <Th>Spend</Th>
                    <Th>Profit</Th>
                    <Th>Status</Th>
                  </tr>
                </thead>
                <tbody>
                  {campaigns.map((c: any) => (
                    <tr key={c.id}>
                      <Td className="font-medium">{c.name}</Td>
                      <Td>{moneyUZS(c.spend)}</Td>
                      <Td>{moneyUZS(c.profit)}</Td>
                      <Td>
                        <Badge tone={c.status === "HARMFUL" ? "high" : c.status === "OK" ? "ok" : "med"}>{c.status}</Badge>
                      </Td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </Card>
          </Section>

          <Section title="Fake lead aniqlash" subtitle="5–10 soniya, 1 sahifa, qaytib kelmagan">
            <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
              {(data.fake_leads || []).map((f: any) => (
                <Card key={f.id} className="p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="font-semibold">{f.source}</div>
                      <div className="text-sm muted">Session: {f.seconds}s • pages: {f.pages}</div>
                      <div className="mt-2 text-sm muted">Reason: {f.reason}</div>
                    </div>
                    <Badge tone="med">FAKE</Badge>
                  </div>
                </Card>
              ))}
            </div>
          </Section>

          <Section title="Landing muammo" subtitle="Bounce / checkout drop / scroll depth">
            <Card className="p-4">
              <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
                {(data.landing || []).map((l: any) => (
                  <div key={l.metric} className="rounded-2xl border border-slate-200 bg-white/60 p-3">
                    <div className="text-sm font-semibold">{l.metric}</div>
                    <div className="text-xs muted">{l.value}</div>
                    <div className="text-xs muted mt-1">{l.note}</div>
                  </div>
                ))}
              </div>
            </Card>
          </Section>
        </>
      ) : (
        <>
          <Section title="To‘laydigan auditoriya" subtitle="Faqat to‘lov qilganlar segmenti">
            <Card className="p-4">
              <Table>
                <thead>
                  <tr>
                    <Th>Segment</Th>
                    <Th>Share</Th>
                    <Th>Channel</Th>
                    <Th>Note</Th>
                  </tr>
                </thead>
                <tbody>
                  {audiences.map((a: any) => (
                    <tr key={a.segment}>
                      <Td className="font-medium">{a.segment}</Td>
                      <Td>{a.share}%</Td>
                      <Td>{a.channel}</Td>
                      <Td className="muted">{a.note}</Td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </Card>
          </Section>

          <Section title="Byudjetni ko‘chirish simulyatsiyasi" subtitle="Zararli kampaniyadan foydalisiga">
            <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
              {(data.budget_moves || []).map((m: any) => (
                <Card key={m.id} className="p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="font-semibold">{m.from} → {m.to}</div>
                      <div className="text-sm muted">Move: {moneyUZS(m.amount)}</div>
                      <div className="mt-2 text-sm muted">Expected profit: {moneyUZS(m.expected_profit)}</div>
                    </div>
                    <Badge tone="ok">SIM</Badge>
                  </div>
                </Card>
              ))}
            </div>
          </Section>

          <Section title="Ad fatigue" subtitle="CTR / conv pasayishi">
            <Card className="p-4">
              <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
                {(data.fatigue || []).map((x: any) => (
                  <div key={x.ad} className="rounded-2xl border border-slate-200 bg-white/60 p-3">
                    <div className="text-sm font-semibold">{x.ad}</div>
                    <div className="text-xs muted">CTR: {x.ctr}%</div>
                    <div className="text-xs muted">Conv: {x.conv}%</div>
                    <div className="text-xs muted mt-1">{x.note}</div>
                  </div>
                ))}
              </div>
            </Card>
          </Section>
        </>
      )}

      {q.error ? (
        <div className="mt-6 rounded-xl border border-rose-200 bg-rose-50 p-3 text-sm text-rose-700">
          {String(q.error)}
        </div>
      ) : null}
    </Page>
  );
}
