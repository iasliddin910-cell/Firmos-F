"use client";

import React, { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Page } from "@/components/Page";
import { apiGet, apiPost } from "@/lib/api";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Section } from "@/components/blocks/Section";
import { dt } from "@/lib/format";

export default function CompanyBrainPage() {
  const [title, setTitle] = useState("Narxni +5% oshirish (pilot)");
  const [proposalText, setProposalText] = useState(
    JSON.stringify({ agent: "SALES", action: "PRICE_INCREASE_5", expected_effect: "+8%" }, null, 2)
  );

  const priorityQ = useQuery({
    queryKey: ["cb", "priority"],
    queryFn: async () => apiGet("/api/v1/company-brain/priority")
  });

  const councilQ = useQuery({
    queryKey: ["cb", "council"],
    queryFn: async () => apiGet("/api/v1/company-brain/council")
  });

  const decisionsQ = useQuery({
    queryKey: ["cb", "decisions"],
    queryFn: async () => apiGet("/api/v1/company-brain/decisions")
  });

  const conflicts = (councilQ.data?.conflicts || []) as any[];
  const decisions = (decisionsQ.data?.decisions || []) as any[];

  const conflictTone = useMemo(() => {
    if (conflicts.some((c) => c.severity === "HIGH")) return "high";
    if (conflicts.some((c) => c.severity === "MED")) return "med";
    return "low";
  }, [conflicts]);

  async function createDecision() {
    const proposal = JSON.parse(proposalText);
    await apiPost("/api/v1/company-brain/decisions", { title, proposal });
    await decisionsQ.refetch();
    await councilQ.refetch();
    await priorityQ.refetch();
  }

  return (
    <Page title="Company Brain">
      <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
        <Card className="p-4">
          <div className="text-sm muted">Council Conflicts</div>
          <div className="mt-1 flex items-center justify-between">
            <div className="text-2xl font-semibold">{conflicts.length}</div>
            <Badge tone={conflictTone}>{conflictTone.toUpperCase()}</Badge>
          </div>
          <div className="mt-2 text-xs muted">Ziddiyat bo‘lsa, kengaytirishdan oldin bartaraf etiladi.</div>
        </Card>

        <Card className="p-4">
          <div className="text-sm muted">Decisions</div>
          <div className="mt-1 text-2xl font-semibold">{decisions.length}</div>
          <div className="mt-2 text-xs muted">Simulyatsiya → Pilot → Result → Approval</div>
        </Card>

        <Card className="p-4">
          <div className="text-sm muted">Priority items</div>
          <div className="mt-1 text-2xl font-semibold">{(priorityQ.data?.items || []).length}</div>
          <div className="mt-2 text-xs muted">Signallar risk + pul ta’siri bo‘yicha saralanadi.</div>
        </Card>
      </div>

      <Section title="New decision" subtitle="Company Brain hech qachon avtomatik implement qilmaydi. Bu faqat nazoratli qaror jurnali.">
        <Card className="p-4">
          <div className="grid gap-3 md:grid-cols-2">
            <div>
              <div className="text-sm font-medium mb-1">Title</div>
              <Input value={title} onChange={(e) => setTitle(e.target.value)} />
              <div className="mt-3 text-sm font-medium mb-1">Proposal (JSON)</div>
              <Textarea rows={8} value={proposalText} onChange={(e) => setProposalText(e.target.value)} />
              <div className="mt-3 flex gap-2">
                <Button onClick={createDecision}>Create</Button>
                <Button variant="secondary" onClick={() => setProposalText(JSON.stringify({ agent: "MARKETING", action: "BUDGET_SHIFT", expected_effect: "+1.2m" }, null, 2))}>
                  Example
                </Button>
              </div>
            </div>

            <div className="rounded-2xl border border-slate-200 bg-white/50 p-4">
              <div className="font-semibold">Master Protocol (konstitutsiya)</div>
              <ul className="mt-2 list-disc pl-5 text-sm muted">
                <li>Agentlar qaror qabul qilmaydi — faqat signal beradi.</li>
                <li>Har taklifda sabab + oqibat bo‘lishi shart.</li>
                <li>Ziddiyat bo‘lsa, “resolve” qilinmaguncha oldinga o‘tish yo‘q.</li>
                <li>Simulyatsiya → pilot → natija → OWNER tasdig‘i.</li>
              </ul>
              <div className="mt-3 text-xs muted">
                Bu frontend “calm UI” va animatsiyalarga ega. Backend bo‘lsa, real KPI’lar bilan ishlaydi.
              </div>
            </div>
          </div>
        </Card>
      </Section>

      <Section title="Conflicts" subtitle="Agentlararo ziddiyatlar (demo conflict engine)">
        <div className="grid gap-3">
          {conflicts.map((c) => (
            <Card key={c.id} className="p-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="font-semibold">{c.id}</div>
                  <div className="text-sm muted">{c.description}</div>
                  <div className="mt-2 text-xs muted">Agents: {(c.involved_agents || []).join(", ")}</div>
                </div>
                <Badge tone={c.severity === "HIGH" ? "high" : c.severity === "MED" ? "med" : "low"}>{c.severity}</Badge>
              </div>
            </Card>
          ))}
          {conflicts.length === 0 ? <div className="muted text-sm">Hozircha ziddiyat aniqlanmadi.</div> : null}
        </div>
      </Section>

      <Section title="Decisions" subtitle="Oxirgi qarorlar jurnali">
        <div className="grid gap-3">
          {decisions.slice().reverse().slice(0, 10).map((d) => (
            <Card key={d.id} className="p-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="font-semibold">{d.title}</div>
                  <div className="text-sm muted">
                    Stage: {d.stage} • Created: {dt(d.created_at)} • Conflicts: {d.conflicts?.length || 0}
                  </div>
                  <div className="mt-2 text-xs font-mono rounded-xl border border-slate-200 bg-white/60 p-2 overflow-auto">
                    {JSON.stringify(d.proposal, null, 2)}
                  </div>
                </div>
                <Badge tone="neutral">{d.stage}</Badge>
              </div>
            </Card>
          ))}
          {decisions.length === 0 ? <div className="muted text-sm">Hozircha decision yo‘q.</div> : null}
        </div>
      </Section>

      {(priorityQ.error || councilQ.error || decisionsQ.error) ? (
        <div className="mt-6 rounded-xl border border-rose-200 bg-rose-50 p-3 text-sm text-rose-700">
          {String(priorityQ.error || councilQ.error || decisionsQ.error)}
        </div>
      ) : null}
    </Page>
  );
}
