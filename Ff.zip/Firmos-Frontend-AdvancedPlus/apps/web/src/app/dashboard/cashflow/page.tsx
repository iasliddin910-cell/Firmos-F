"use client";

import React from "react";
import { useQuery } from "@tanstack/react-query";
import { Page } from "@/components/Page";
import { apiGet } from "@/lib/api";
import { KpiCard } from "@/components/blocks/KpiCard";
import { Section } from "@/components/blocks/Section";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, Td, Th } from "@/components/blocks/Table";
import { moneyUZS } from "@/lib/format";

export default function CashflowPage() {
  const q = useQuery({
    queryKey: ["cashflow", "summary"],
    queryFn: async () => apiGet("/api/v1/agents/cashflow/insights/summary")
  });

  const data = q.data || {};
  const kpis = data.kpis || {};

  return (
    <Page title="Cashflow Agent">
      <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
        <KpiCard title="Runway" value={`${kpis.runway_days ?? 0} kun`} sub="Pul tugashigacha taxmin" tone={(kpis.runway_days ?? 0) < 60 ? "high" : "ok"} />
        <KpiCard title="Oyma-oy burn" value={moneyUZS(kpis.monthly_burn ?? 0)} sub="Daromad - xarajat" tone="med" />
        <KpiCard title="Daily cash stress" value={kpis.daily_stress ?? "STABLE"} sub="Ketma-ket minus bo‘lsa kuchayadi" tone={kpis.daily_stress === "HIGH" ? "high" : "ok"} />
      </div>

      <Section title="Expense drain" subtitle="Natijasiz xarajatlar">
        <Card className="p-4">
          <Table>
            <thead>
              <tr>
                <Th>Category</Th>
                <Th>Monthly</Th>
                <Th>Return</Th>
                <Th>Note</Th>
              </tr>
            </thead>
            <tbody>
              {(data.expense_drain || []).map((x: any) => (
                <tr key={x.category}>
                  <Td className="font-medium">{x.category}</Td>
                  <Td>{moneyUZS(x.monthly)}</Td>
                  <Td>{moneyUZS(x.return)}</Td>
                  <Td className="muted">{x.note}</Td>
                </tr>
              ))}
            </tbody>
          </Table>
        </Card>
      </Section>

      <Section title="Hidden cash leaks" subtitle="Mayda, takrorlanuvchi to‘lovlar">
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
          {(data.hidden_leaks || []).map((l: any) => (
            <Card key={l.id} className="p-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="font-semibold">{l.title}</div>
                  <div className="text-sm muted">{l.freq} • {moneyUZS(l.amount)} • Yiliga: {moneyUZS(l.yearly)}</div>
                </div>
                <Badge tone="med">LEAK</Badge>
              </div>
            </Card>
          ))}
        </div>
      </Section>

      <Section title="Forward cash risk" subtitle="30/60/90 kun prognoz">
        <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
          {(data.forward_risk || []).map((r: any) => (
            <Card key={r.days} className="p-4">
              <div className="text-sm muted">{r.days} kun</div>
              <div className="mt-1 flex items-center justify-between">
                <div className="text-xl font-semibold">{r.status}</div>
                <Badge tone={r.status === "HIGH" ? "high" : r.status === "MED" ? "med" : "ok"}>{r.status}</Badge>
              </div>
              <div className="mt-2 text-xs muted">{r.note}</div>
            </Card>
          ))}
        </div>
      </Section>

      {q.error ? (
        <div className="mt-6 rounded-xl border border-rose-200 bg-rose-50 p-3 text-sm text-rose-700">
          {String(q.error)}
        </div>
      ) : null}
    </Page>
  );
}
