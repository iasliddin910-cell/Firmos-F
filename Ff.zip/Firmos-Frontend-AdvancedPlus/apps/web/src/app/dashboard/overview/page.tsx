"use client";

import React from "react";
import { useQuery } from "@tanstack/react-query";
import { Page } from "@/components/Page";
import { apiGet } from "@/lib/api";
import { AgentSignalSchema } from "@firmos/shared";
import { z } from "zod";
import { KpiCard } from "@/components/blocks/KpiCard";
import { Section } from "@/components/blocks/Section";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { dt } from "@/lib/format";

const SignalsResponse = z.object({
  items: z.array(AgentSignalSchema)
});

export default function OverviewPage() {
  const q = useQuery({
    queryKey: ["signals"],
    queryFn: async () => SignalsResponse.parse(await apiGet("/api/v1/signals"))
  });

  const items = q.data?.items || [];
  const high = items.filter((x) => x.riskLevel === "HIGH").length;
  const med = items.filter((x) => x.riskLevel === "MED").length;
  const low = items.filter((x) => x.riskLevel === "LOW").length;

  const byAgent = items.reduce<Record<string, number>>((acc, s) => {
    acc[s.agent] = (acc[s.agent] || 0) + 1;
    return acc;
  }, {});

  return (
    <Page title="Overview">
      <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
        <KpiCard title="Signals" value={String(items.length)} sub="Oxirgi monitoring snapshot" tone="ok" />
        <KpiCard title="High risk" value={String(high)} sub="Zudlik bilan ko‘rish kerak" tone="high" />
        <KpiCard title="Medium risk" value={String(med)} sub={`Low: ${low}`} tone="med" />
      </div>

      <Section
        title="Agentlar bo‘yicha"
        subtitle="Qaysi agentda ko‘proq signal bor (demo data yoki real API’dan)"
      >
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2 lg:grid-cols-3">
          {Object.keys(byAgent).sort().map((k) => (
            <Card key={k} className="p-4">
              <div className="flex items-center justify-between">
                <div className="font-semibold">{k}</div>
                <Badge tone="neutral">{byAgent[k]}</Badge>
              </div>
              <div className="mt-2 text-sm muted">Agent holatini dashboard sahifasida ko‘ring.</div>
            </Card>
          ))}
        </div>
      </Section>

      <Section title="Oxirgi signallar" subtitle="Risk va sabablar bilan">
        <div className="grid gap-3">
          {items.slice(0, 12).map((s) => (
            <Card key={s.id} className="p-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="font-semibold">{s.title}</div>
                  <div className="text-sm muted">{s.agent} • {dt(s.created_at)} • Confidence {(s.confidence * 100).toFixed(0)}%</div>
                  <ul className="mt-2 list-disc pl-5 text-sm">
                    {s.why.slice(0, 4).map((w, i) => (
                      <li key={i} className="muted">{w}</li>
                    ))}
                  </ul>
                </div>
                <Badge tone={s.riskLevel === "HIGH" ? "high" : s.riskLevel === "MED" ? "med" : "low"}>{s.riskLevel}</Badge>
              </div>

              {s.legal_basis?.length ? (
                <div className="mt-3 rounded-xl border border-slate-200 bg-white/50 p-3">
                  <div className="text-xs font-semibold">QONUNIY ASOS (registry’dan)</div>
                  <div className="mt-1 text-xs muted">
                    {s.legal_basis.map((b) => b.citation_label).join(" • ")}
                  </div>
                </div>
              ) : null}
            </Card>
          ))}
          {items.length === 0 ? <div className="muted text-sm">Hozircha signal yo‘q.</div> : null}
        </div>
      </Section>

      {q.error ? (
        <div className="mt-6 rounded-xl border border-rose-200 bg-rose-50 p-3 text-sm text-rose-700">
          {String(q.error)}
        </div>
      ) : null}
    </Page>
  );
}
