"use client";

import React from "react";
import { useQuery } from "@tanstack/react-query";
import { Page } from "@/components/Page";
import { apiGet } from "@/lib/api";
import { KpiCard } from "@/components/blocks/KpiCard";
import { Section } from "@/components/blocks/Section";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, Td, Th } from "@/components/blocks/Table";
import { moneyUZS } from "@/lib/format";

export default function CyberPage() {
  const q = useQuery({
    queryKey: ["cyber", "summary"],
    queryFn: async () => apiGet("/api/v1/agents/cyber/insights/summary")
  });

  const data = q.data || {};
  const k = data.kpis || {};

  return (
    <Page title="Cybersecurity Agent">
      <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
        <KpiCard title="Security risk score" value={`${k.risk_score ?? 78}/100`} sub="Yuqori bo‘lsa incidentga yaqin" tone={k.risk_level === "HIGH" ? "high" : "med"} />
        <KpiCard title="Infra health" value={`${k.infra_health ?? 41}/100`} sub="CPU/RAM/errors" tone={(k.infra_health ?? 100) < 60 ? "med" : "ok"} />
        <KpiCard title="Downtime impact (today)" value={moneyUZS(k.downtime_loss_today ?? 0)} sub="Taxminiy yo‘qotish" tone="high" />
      </div>

      <Section title="Anomalous logins" subtitle="No‘odatiy joy/vaqt/urinishlar">
        <Card className="p-4">
          <Table>
            <thead>
              <tr>
                <Th>Time</Th>
                <Th>IP</Th>
                <Th>Geo</Th>
                <Th>Reason</Th>
              </tr>
            </thead>
            <tbody>
              {(data.anomalous_logins || []).map((x: any) => (
                <tr key={x.id}>
                  <Td className="muted">{x.time}</Td>
                  <Td className="font-mono text-xs">{x.ip}</Td>
                  <Td>{x.geo}</Td>
                  <Td className="muted">{x.reason}</Td>
                </tr>
              ))}
            </tbody>
          </Table>
        </Card>
      </Section>

      <Section title="Bot / brute-force" subtitle="Sun’iy trafik va urinishlar">
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
          {(data.bot_events || []).map((b: any) => (
            <Card key={b.id} className="p-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="font-semibold">{b.title}</div>
                  <div className="text-sm muted">{b.note}</div>
                </div>
                <Badge tone="med">BOT</Badge>
              </div>
            </Card>
          ))}
        </div>
      </Section>

      <Section title="Data leak risk" subtitle="Katta eksport / tunda yuklab olish">
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
          {(data.data_leaks || []).map((d: any) => (
            <Card key={d.id} className="p-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="font-semibold">{d.title}</div>
                  <div className="text-sm muted">{d.note}</div>
                </div>
                <Badge tone="high">HIGH</Badge>
              </div>
            </Card>
          ))}
        </div>
        <div className="mt-2 text-xs muted">
          Eslatma: Agent serverni avtomatik o‘chirmaydi (safety). Faqat signal + tavsiya.
        </div>
      </Section>

      {q.error ? (
        <div className="mt-6 rounded-xl border border-rose-200 bg-rose-50 p-3 text-sm text-rose-700">
          {String(q.error)}
        </div>
      ) : null}
    </Page>
  );
}
