"use client";

import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Page } from "@/components/Page";
import { apiGet, apiPost } from "@/lib/api";
import { KpiCard } from "@/components/blocks/KpiCard";
import { Section } from "@/components/blocks/Section";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Table, Td, Th } from "@/components/blocks/Table";

export default function CompliancePage() {
  const q = useQuery({
    queryKey: ["compliance", "summary"],
    queryFn: async () => apiGet("/api/v1/agents/compliance/insights/summary")
  });

  const data = q.data || {};
  const k = data.kpis || {};
  const [contract, setContract] = useState("Shartnoma matnini shu yerga paste qiling (demo).");
  const [contractRes, setContractRes] = useState<any>(null);

  async function scanContract() {
    const r = await apiPost("/api/v1/agents/compliance/contract/scan", { text: contract });
    setContractRes(r);
  }

  return (
    <Page title="Compliance Agent">
      <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
        <KpiCard title="Compliance risk score" value={`${k.risk_score ?? 62}/100`} sub="O‘rta bo‘lsa ham monitoring kerak" tone={k.risk_level === "HIGH" ? "high" : k.risk_level === "MED" ? "med" : "ok"} />
        <KpiCard title="Deadlines" value={String(k.deadlines ?? 0)} sub="Litsenziya/hisobot/hujjat" tone="med" />
        <KpiCard title="Law changes" value={String(k.law_changes ?? 0)} sub="Rasmiy manbalar asosida" tone="ok" />
      </div>

      <Section title="Law Change Monitor" subtitle="Lex.uz / rasmiy qarorlar (demo registry)">
        <div className="grid gap-3">
          {(data.law_changes || []).map((x: any) => (
            <Card key={x.id} className="p-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="font-semibold">{x.title}</div>
                  <div className="text-sm muted">Effective: {x.effective_from}</div>
                  <div className="mt-2 text-sm muted">{x.note}</div>
                </div>
                <Badge tone={x.risk === "HIGH" ? "high" : x.risk === "MED" ? "med" : "ok"}>{x.risk}</Badge>
              </div>
            </Card>
          ))}
        </div>
      </Section>

      <Section title="Deadline Tracker" subtitle="Muddati yaqin hujjatlar">
        <Card className="p-4">
          <Table>
            <thead>
              <tr>
                <Th>Item</Th>
                <Th>Days left</Th>
                <Th>Impact</Th>
              </tr>
            </thead>
            <tbody>
              {(data.deadlines || []).map((d: any) => (
                <tr key={d.item}>
                  <Td className="font-medium">{d.item}</Td>
                  <Td>{d.days_left}</Td>
                  <Td className="muted">{d.impact}</Td>
                </tr>
              ))}
            </tbody>
          </Table>
        </Card>
      </Section>

      <Section title="Contract Risk Scan" subtitle="Shartnoma xavf bandlari (demo NLP — hujjat topshirish emas)">
        <Card className="p-4">
          <Textarea rows={6} value={contract} onChange={(e) => setContract(e.target.value)} />
          <div className="mt-2 flex gap-2">
            <Button onClick={scanContract}>Scan</Button>
            <Button variant="secondary" onClick={() => setContract("Jarima: bir tomonlama 10%... (demo)")} >
              Example
            </Button>
          </div>

          {contractRes ? (
            <div className="mt-3 rounded-2xl border border-slate-200 bg-white/60 p-3 text-sm">
              <div className="text-xs font-semibold">Result</div>
              <div className="mt-2 muted whitespace-pre-wrap">{JSON.stringify(contractRes, null, 2)}</div>
            </div>
          ) : null}
        </Card>
      </Section>

      <Section title="Cross‑Agent Check" subtitle="Agent takliflari qonunga zid emasmi?">
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
          {(data.cross_checks || []).map((c: any) => (
            <Card key={c.id} className="p-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="font-semibold">{c.proposal}</div>
                  <div className="text-sm muted">{c.note}</div>
                </div>
                <Badge tone={c.status === "BLOCK" ? "high" : c.status === "WARN" ? "med" : "ok"}>{c.status}</Badge>
              </div>
            </Card>
          ))}
        </div>
      </Section>

      {q.error ? (
        <div className="mt-6 rounded-xl border border-rose-200 bg-rose-50 p-3 text-sm text-rose-700">
          {String(q.error)}
        </div>
      ) : null}
    </Page>
  );
}
