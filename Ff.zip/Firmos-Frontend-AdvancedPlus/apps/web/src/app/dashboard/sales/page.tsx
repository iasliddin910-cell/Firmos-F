"use client";

import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Page } from "@/components/Page";
import { apiGet } from "@/lib/api";
import { Tabs } from "@/components/ui/tabs";
import { KpiCard } from "@/components/blocks/KpiCard";
import { Section } from "@/components/blocks/Section";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, Td, Th } from "@/components/blocks/Table";
import { moneyUZS } from "@/lib/format";

export default function SalesPage() {
  const [tab, setTab] = useState<"loss" | "profit">("loss");

  const q = useQuery({
    queryKey: ["sales", "summary"],
    queryFn: async () => apiGet("/api/v1/agents/sales/insights/summary")
  });

  const data = q.data || {};
  const kpis = data.kpis || {};
  const funnel = data.funnel || [];
  const channel = data.channel || [];
  const complaints = data.complaints || [];
  const segments = data.segments || [];

  return (
    <Page title="Sales Agent">
      <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
        <KpiCard title="Yo‘qotilgan sof foyda (24h)" value={moneyUZS(kpis.loss_24h ?? 0)} sub="Bekor/to‘lanmagan/yetib bormagan" tone="high" />
        <KpiCard title="Potensial yo‘qotish (funnel)" value={moneyUZS(kpis.funnel_loss ?? 0)} sub="Checkout/payment drop" tone="med" />
        <KpiCard title="Konversiya (7d)" value={`${(kpis.conv_7d ?? 0).toFixed(1)}%`} sub="Shikoyat kamayganda oshishi mumkin" tone="ok" />
      </div>

      <div className="mt-4">
        <Tabs
          value={tab}
          onChange={(v) => setTab(v as any)}
          tabs={[
            { key: "loss", label: "LOSS Intelligence" },
            { key: "profit", label: "PROFIT Discovery" }
          ]}
        />
      </div>

      {tab === "loss" ? (
        <>
          <Section title="Funnel’da chiqib ketish" subtitle="Checkout → Payment → Confirmation">
            <Card className="p-4">
              <Table>
                <thead>
                  <tr>
                    <Th>Stage</Th>
                    <Th>Drop users</Th>
                    <Th>Potential loss</Th>
                  </tr>
                </thead>
                <tbody>
                  {funnel.map((r: any) => (
                    <tr key={r.stage}>
                      <Td className="font-medium">{r.stage}</Td>
                      <Td>{r.drop_users}</Td>
                      <Td>{moneyUZS(r.potential_loss)}</Td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </Card>
          </Section>

          <Section title="Kanal bo‘yicha zarar" subtitle="Telegram / Website / App / Marketplace">
            <Card className="p-4">
              <Table>
                <thead>
                  <tr>
                    <Th>Channel</Th>
                    <Th>Orders</Th>
                    <Th>Profit</Th>
                    <Th>Risk</Th>
                  </tr>
                </thead>
                <tbody>
                  {channel.map((c: any) => (
                    <tr key={c.channel}>
                      <Td className="font-medium">{c.channel}</Td>
                      <Td>{c.orders}</Td>
                      <Td>{moneyUZS(c.profit)}</Td>
                      <Td>
                        <Badge tone={c.risk === "HIGH" ? "high" : c.risk === "MED" ? "med" : "low"}>{c.risk}</Badge>
                      </Td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </Card>
          </Section>

          <Section title="Shikoyat → foyda yo‘qotish" subtitle="Mavzular va taxminiy ta’sir">
            <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
              {complaints.map((c: any) => (
                <Card key={c.topic} className="p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="font-semibold">{c.topic}</div>
                      <div className="text-sm muted">{c.linked_to}</div>
                      <div className="mt-2 text-sm muted">Count: {c.count}</div>
                      <div className="text-sm muted">Estimated loss: {moneyUZS(c.estimated_loss)}</div>
                    </div>
                    <Badge tone="med">{c.impact}</Badge>
                  </div>
                </Card>
              ))}
            </div>
          </Section>
        </>
      ) : (
        <>
          <Section title="Foyda oshirish imkoniyatlari" subtitle="Narx/vaqt/kanal/xulq + shikoyat kamaygan paytlar">
            <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
              {(data.opportunities || []).map((o: any) => (
                <Card key={o.id} className="p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="font-semibold">{o.title}</div>
                      <div className="text-sm muted">{o.reason}</div>
                      <div className="mt-2 text-sm muted">Expected uplift: {o.expected_uplift}</div>
                    </div>
                    <Badge tone="ok">SIM</Badge>
                  </div>
                </Card>
              ))}
            </div>
          </Section>

          <Section title="Eng foydali mijozlar segmenti" subtitle="Kam shikoyat qiladi, lekin ko‘p foyda keltiradi">
            <Card className="p-4">
              <Table>
                <thead>
                  <tr>
                    <Th>Segment</Th>
                    <Th>ARPU</Th>
                    <Th>Complaints</Th>
                    <Th>Note</Th>
                  </tr>
                </thead>
                <tbody>
                  {segments.map((s: any) => (
                    <tr key={s.segment}>
                      <Td className="font-medium">{s.segment}</Td>
                      <Td>{moneyUZS(s.arpu)}</Td>
                      <Td>{s.complaints}</Td>
                      <Td className="muted">{s.note}</Td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </Card>
          </Section>

          <Section title="Vaqt va foyda" subtitle="Soat bo‘yicha konversiya va shikoyat">
            <Card className="p-4">
              <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
                {(data.time_windows || []).map((t: any) => (
                  <div key={t.hour} className="rounded-2xl border border-slate-200 bg-white/60 p-3">
                    <div className="text-sm font-semibold">{t.hour}:00</div>
                    <div className="text-xs muted">Conv: {t.conversion}%</div>
                    <div className="text-xs muted">Complaints: {t.complaints}</div>
                  </div>
                ))}
              </div>
            </Card>
          </Section>
        </>
      )}

      {q.error ? (
        <div className="mt-6 rounded-xl border border-rose-200 bg-rose-50 p-3 text-sm text-rose-700">
          {String(q.error)}
        </div>
      ) : null}
    </Page>
  );
}
