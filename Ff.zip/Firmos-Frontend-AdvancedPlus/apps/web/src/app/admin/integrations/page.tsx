"use client";

import React, { useMemo, useState } from "react";
import { Page } from "@/components/Page";
import { Section } from "@/components/blocks/Section";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { apiPost } from "@/lib/api";

type Connector = {
  id: string;
  label: string;
  fields: Array<{ key: string; label: string; placeholder?: string }>;
};

const CONNECTORS: Connector[] = [
  { id: "telegram", label: "Telegram Bot", fields: [{ key: "bot_token", label: "Bot token" }] },
  { id: "website", label: "Website", fields: [{ key: "domain", label: "Domain", placeholder: "https://example.com" }] },
  { id: "app", label: "Mobile App", fields: [{ key: "app_id", label: "App ID" }] },
  { id: "meta_ads", label: "Meta Ads", fields: [{ key: "access_token", label: "Access token" }, { key: "ad_account_id", label: "Ad account id" }] },
  { id: "google_ads", label: "Google Ads", fields: [{ key: "developer_token", label: "Developer token" }, { key: "customer_id", label: "Customer id" }] },
  { id: "tiktok_ads", label: "TikTok Ads", fields: [{ key: "access_token", label: "Access token" }, { key: "advertiser_id", label: "Advertiser id" }] },
  { id: "payme", label: "Payme", fields: [{ key: "merchant_id", label: "Merchant id" }, { key: "secret", label: "Secret" }] },
  { id: "click", label: "Click", fields: [{ key: "service_id", label: "Service id" }, { key: "secret", label: "Secret" }] },
  { id: "stripe", label: "Stripe", fields: [{ key: "secret_key", label: "Secret key" }] },
  { id: "bank_csv", label: "Bank CSV import", fields: [{ key: "bank_name", label: "Bank name" }] }
];

export default function IntegrationsPage() {
  const [active, setActive] = useState(CONNECTORS[0].id);
  const [status, setStatus] = useState<Record<string, string>>({});
  const [values, setValues] = useState<Record<string, Record<string, string>>>({});

  const connector = useMemo(() => CONNECTORS.find((c) => c.id === active)!, [active]);

  function setField(key: string, value: string) {
    setValues((prev) => ({
      ...prev,
      [active]: { ...(prev[active] || {}), [key]: value }
    }));
  }

  async function testConnection() {
    const payload = { connector: active, config: values[active] || {} };
    const r = await apiPost("/api/v1/admin/integrations/test", payload);
    setStatus((prev) => ({ ...prev, [active]: r.status || "UNKNOWN" }));
  }

  return (
    <Page title="Admin — Integrations Center">
      <div className="grid grid-cols-1 gap-3 lg:grid-cols-[280px_1fr]">
        <Card className="p-4">
          <div className="text-sm font-semibold mb-2">Connectors</div>
          <div className="flex flex-col gap-2">
            {CONNECTORS.map((c) => (
              <button
                key={c.id}
                onClick={() => setActive(c.id)}
                className={
                  "rounded-xl border px-3 py-2 text-left text-sm transition " +
                  (active === c.id ? "bg-slate-900 text-white border-slate-900" : "bg-white/60 border-slate-200 hover:bg-white/80")
                }
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="font-medium">{c.label}</span>
                  <Badge tone={status[c.id] === "OK" ? "ok" : status[c.id] === "FAIL" ? "high" : "neutral"}>
                    {status[c.id] || "NOT_SET"}
                  </Badge>
                </div>
              </button>
            ))}
          </div>
        </Card>

        <div className="grid gap-3">
          <Section title={connector.label} subtitle="UI tayyor. Real integratsiya uchun backend connector talab qilinadi.">
            <Card className="p-4">
              <div className="grid gap-3 md:grid-cols-2">
                {connector.fields.map((f) => (
                  <div key={f.key}>
                    <div className="text-sm font-medium mb-1">{f.label}</div>
                    <Input
                      value={(values[active] || {})[f.key] || ""}
                      onChange={(e) => setField(f.key, e.target.value)}
                      placeholder={f.placeholder}
                    />
                  </div>
                ))}
              </div>

              <div className="mt-3 flex gap-2">
                <Button onClick={testConnection}>Test connection</Button>
                <Button
                  variant="secondary"
                  onClick={() => {
                    setValues((prev) => ({ ...prev, [active]: {} }));
                    setStatus((prev) => ({ ...prev, [active]: "NOT_SET" }));
                  }}
                >
                  Reset
                </Button>
              </div>

              <div className="mt-3 rounded-xl border border-slate-200 bg-white/50 p-3 text-xs muted">
                <div className="font-semibold text-slate-900">Important</div>
                <ul className="mt-2 list-disc pl-5">
                  <li>Frontend bu yerda faqat config yig‘adi.</li>
                  <li>API test: `/api/v1/admin/integrations/test` (local mock yoki real backend).</li>
                  <li>Secret’larni production’da server-side saqlash shart.</li>
                </ul>
              </div>
            </Card>
          </Section>
        </div>
      </div>
    </Page>
  );
}
