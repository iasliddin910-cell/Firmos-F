"use client";

import React, { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Page } from "@/components/Page";
import { apiDelete, apiGet, apiPost, apiPut } from "@/lib/api";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Table, Td, Th } from "@/components/blocks/Table";
import { Section } from "@/components/blocks/Section";

export default function LegalSourcesPage() {
  const q = useQuery({
    queryKey: ["admin", "legal-sources"],
    queryFn: async () => apiGet("/api/v1/admin/legal-sources")
  });

  const items: any[] = q.data?.items || [];
  const [selected, setSelected] = useState<any | null>(null);

  const [form, setForm] = useState<any>({
    jurisdiction: "UZ",
    source_type: "TAX_CODE",
    title: "Soliq kodeksi: QQS majburiyati threshold (demo)",
    reference_code: "VAT_THRESHOLD",
    effective_from: "2025-01-01",
    text_content: "Rasmiy manbadan olingan matn shu yerda saqlanadi (demo).",
    metadata_json: { threshold_12m_turnover: 1000000000 }
  });

  const canSave = useMemo(() => form.title && form.reference_code && form.text_content, [form]);

  async function create() {
    await apiPost("/api/v1/admin/legal-sources", form);
    await q.refetch();
  }

  async function update() {
    if (!selected) return;
    await apiPut(`/api/v1/admin/legal-sources/${selected.id}`, form);
    setSelected(null);
    await q.refetch();
  }

  async function remove(id: string) {
    await apiDelete(`/api/v1/admin/legal-sources/${id}`);
    await q.refetch();
  }

  function loadToForm(item: any) {
    setSelected(item);
    setForm({
      jurisdiction: item.jurisdiction,
      source_type: item.source_type,
      title: item.title,
      reference_code: item.reference_code,
      effective_from: item.effective_from,
      effective_to: item.effective_to || "",
      text_content: item.text_content,
      metadata_json: item.metadata_json || {}
    });
  }

  return (
    <Page title="Admin — Legal Sources (OFFICIAL ONLY)">
      <div className="rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900">
        Qat’iy qoida: Tax/Compliance hisoblari <b>faqat rasmiy manbalar</b>ga tayanadi.
        Blog/YouTube/“kimdir aytdi” — ruxsat yo‘q.
      </div>

      <Section title="Registry" subtitle="Legal sources ro‘yxati (admin-only)">
        <Card className="p-4">
          <Table>
            <thead>
              <tr>
                <Th>Title</Th>
                <Th>Type</Th>
                <Th>Ref</Th>
                <Th>Effective</Th>
                <Th></Th>
              </tr>
            </thead>
            <tbody>
              {items.map((it) => (
                <tr key={it.id}>
                  <Td className="font-medium">{it.title}</Td>
                  <Td><Badge tone="neutral">{it.source_type}</Badge></Td>
                  <Td className="font-mono text-xs">{it.reference_code}</Td>
                  <Td className="muted">{it.effective_from}</Td>
                  <Td className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button variant="secondary" onClick={() => loadToForm(it)}>Edit</Button>
                      <Button variant="danger" onClick={() => remove(it.id)}>Delete</Button>
                    </div>
                  </Td>
                </tr>
              ))}
            </tbody>
          </Table>
          {items.length === 0 ? <div className="muted mt-3 text-sm">Registry bo‘sh.</div> : null}
        </Card>
      </Section>

      <Section title={selected ? "Edit source" : "Add source"} subtitle="Matnni rasmiy manbadan (Lex.uz va h.k.) qo‘ying">
        <Card className="p-4">
          <div className="grid gap-3 md:grid-cols-2">
            <div>
              <div className="text-sm font-medium mb-1">Title</div>
              <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
            </div>
            <div>
              <div className="text-sm font-medium mb-1">Reference code</div>
              <Input value={form.reference_code} onChange={(e) => setForm({ ...form, reference_code: e.target.value })} />
            </div>
            <div>
              <div className="text-sm font-medium mb-1">Source type</div>
              <Input value={form.source_type} onChange={(e) => setForm({ ...form, source_type: e.target.value })} placeholder="TAX_CODE / OFFICIAL_DECISION / OFFICIAL_EXPLANATION" />
            </div>
            <div>
              <div className="text-sm font-medium mb-1">Effective from</div>
              <Input value={form.effective_from} onChange={(e) => setForm({ ...form, effective_from: e.target.value })} placeholder="YYYY-MM-DD" />
            </div>
          </div>

          <div className="mt-3">
            <div className="text-sm font-medium mb-1">Text content (official)</div>
            <Textarea rows={7} value={form.text_content} onChange={(e) => setForm({ ...form, text_content: e.target.value })} />
          </div>

          <div className="mt-3">
            <div className="text-sm font-medium mb-1">Metadata JSON (rules)</div>
            <Textarea
              rows={5}
              value={JSON.stringify(form.metadata_json || {}, null, 2)}
              onChange={(e) => {
                try {
                  setForm({ ...form, metadata_json: JSON.parse(e.target.value) });
                } catch {
                  // ignore parse while typing
                }
              }}
            />
            <div className="mt-1 text-xs muted">Bu metadata Tax/Compliance hisob qoidalariga ishlatiladi.</div>
          </div>

          <div className="mt-3 flex gap-2">
            {selected ? (
              <>
                <Button onClick={update} disabled={!canSave}>Update</Button>
                <Button variant="secondary" onClick={() => setSelected(null)}>Cancel</Button>
              </>
            ) : (
              <Button onClick={create} disabled={!canSave}>Create</Button>
            )}
          </div>
        </Card>
      </Section>

      {q.error ? (
        <div className="mt-6 rounded-xl border border-rose-200 bg-rose-50 p-3 text-sm text-rose-700">
          {String(q.error)}
        </div>
      ) : null}
    </Page>
  );
}
