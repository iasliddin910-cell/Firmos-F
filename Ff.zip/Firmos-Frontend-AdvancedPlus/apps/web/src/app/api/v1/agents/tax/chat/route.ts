import { NextResponse, type NextRequest } from "next/server";
import { loadDb } from "@/server/store";
import { requireRole } from "@/server/rbac";

export async function POST(req: NextRequest) {
  const auth = requireRole(req, "ANALYST");
  if (!auth.ok) return NextResponse.json({ error: "forbidden", role: auth.role }, { status: 403 });

  const body = await req.json().catch(() => ({}));
  const message = String(body.message || "").trim().toLowerCase();
  const db = loadDb();

  const citations: any[] = [];
  const pick = (ref: string) => db.legal_sources.find((s) => s.reference_code === ref);

  let holat = "Sizning savolingiz qabul qilindi (demo).";
  let qonun = "Rasmiy manbalar registry’dan tekshiriladi.";
  let oqibat = "Bu maslahat xarakterida. Buxgalter/yurist bilan tasdiqlang.";

  if (!message) {
    return NextResponse.json({
      HOLAT: "Savol bo‘sh.",
      QONUNIY_ASOS: "—",
      OQIBAT_XAVF: "Savol kiriting. Buxgalter bilan tasdiqlang.",
      citations: [],
      disclaimer: "Advice only. No submission / no login / no signing."
    });
  }

  if (message.includes("qqs") || message.includes("vat")) {
    holat = "QQS (VAT) bo‘yicha savol.";
    const src1 = pick("VAT_THRESHOLD");
    const src2 = pick("VAT_EXIT_RULES");
    if (src1) citations.push({ legal_source_id: src1.id, citation_label: `${src1.source_type}:${src1.reference_code}` });
    if (src2) citations.push({ legal_source_id: src2.id, citation_label: `${src2.source_type}:${src2.reference_code}` });

    if (citations.length) {
      qonun = `Registry’dan rasmiy manbalar topildi: ${citations.map((c) => c.citation_label).join(" • ")}.`;
      oqibat = "QQS bo‘yicha qaror (kirish/chiqish) soliq majburiyatiga ta’sir qiladi. Hisob-kitobni buxgalter bilan tasdiqlang.";
    } else {
      qonun = "QQS bo‘yicha rasmiy manba registry’da yo‘q. Citationsni uydirib bo‘lmaydi.";
      oqibat = "Registry’ga rasmiy manba kiritilmaguncha aniq javob berib bo‘lmaydi. Buxgalter bilan tasdiqlang.";
    }
  } else if (message.includes("orti") || message.includes("overpayment")) {
    holat = "Ortiqcha soliq to‘lovi ehtimoli (demo).";
    const src = pick("EXPECTED_TAX_FORMULA");
    if (src) citations.push({ legal_source_id: src.id, citation_label: `${src.source_type}:${src.reference_code}` });
    qonun = citations.length ? "Ortiqcha to‘lov faqat rasmiy formula asosida aniqlanadi." : "Expected formula manbasi registry’da yo‘q.";
    oqibat = "Ortiqcha to‘lov bo‘lsa, offset/refund jarayoni bor. Buxgalter bilan tasdiqlang.";
  } else {
    holat = "Sizning savolingiz umumiy ko‘rinishda (demo).";
    qonun = "Agar savol bo‘yicha rasmiy manba registry’da bo‘lmasa, tizim citation bermaydi.";
    oqibat = "Aniq javob uchun savolni konkretlashtiring va buxgalter/yurist bilan tasdiqlang.";
  }

  return NextResponse.json({
    HOLAT: holat,
    QONUNIY_ASOS: qonun,
    OQIBAT_XAVF: oqibat,
    citations,
    disclaimer: "Advice only. No submission / no login / no signing."
  });
}
