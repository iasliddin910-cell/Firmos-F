import { NextResponse, type NextRequest } from "next/server";
import { loadDb } from "@/server/store";
import { requireRole } from "@/server/rbac";

export async function POST(req: NextRequest) {
  const auth = requireRole(req, "OPERATOR");
  if (!auth.ok) return NextResponse.json({ error: "forbidden", role: auth.role }, { status: 403 });

  const body = await req.json().catch(() => ({}));
  const document_id = String(body.document_id || "");
  const report_type = String(body.report_type || "UNKNOWN");

  const db = loadDb();
  const doc = db.tax_documents.find((d) => d.id === document_id);

  if (!doc) return NextResponse.json({ error: "document_not_found" }, { status: 404 });

  const errors: string[] = [];
  if (doc.parse_status !== "PARSED") errors.push("Document not parsed. Manual totals entry required.");

  // demo validations
  if (report_type.toUpperCase() === "VAT" && !doc.parsed_json) errors.push("VAT totals missing in parsed_json.");

  return NextResponse.json({
    document_id,
    report_type,
    validation_status: errors.length ? "INVALID" : "VALID",
    errors,
    ready_to_submit: errors.length === 0,
    note: "Prepare/validate only. Submission is not supported.",
  });
}
