import { NextResponse, type NextRequest } from "next/server";
import { loadDb } from "@/server/store";
import { requireRole } from "@/server/rbac";

export async function GET(req: NextRequest) {
  const auth = requireRole(req, "ANALYST");
  if (!auth.ok) return NextResponse.json({ error: "forbidden", role: auth.role }, { status: 403 });

  const db = loadDb();
  const basis = db.legal_sources.length > 0 ? "CONFIGURED" : "MISSING";
  const documents = db.tax_documents.length;

  const risks = Math.max(0, documents ? 2 : 0);

  return NextResponse.json({
    kpis: {
      basis_coverage: basis,
      risks,
      documents
    }
  });
}
