import { NextResponse, type NextRequest } from "next/server";
import { loadDb, saveDb } from "@/server/store";
import { requireRole } from "@/server/rbac";

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const auth = requireRole(req, "ADMIN");
  if (!auth.ok) return NextResponse.json({ error: "forbidden", role: auth.role }, { status: 403 });

  const db = loadDb();
  const it = db.legal_sources.find((x) => x.id === params.id);
  if (!it) return NextResponse.json({ error: "not_found" }, { status: 404 });
  return NextResponse.json(it);
}

export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  const auth = requireRole(req, "ADMIN");
  if (!auth.ok) return NextResponse.json({ error: "forbidden", role: auth.role }, { status: 403 });

  const body = await req.json().catch(() => ({}));
  const db = loadDb();
  const idx = db.legal_sources.findIndex((x) => x.id === params.id);
  if (idx < 0) return NextResponse.json({ error: "not_found" }, { status: 404 });

  db.legal_sources[idx] = {
    ...db.legal_sources[idx],
    ...body,
    id: params.id
  };

  saveDb(db);
  return NextResponse.json({ ok: true });
}

export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  const auth = requireRole(req, "ADMIN");
  if (!auth.ok) return NextResponse.json({ error: "forbidden", role: auth.role }, { status: 403 });

  const db = loadDb();
  db.legal_sources = db.legal_sources.filter((x) => x.id !== params.id);
  saveDb(db);
  return NextResponse.json({ ok: true });
}
