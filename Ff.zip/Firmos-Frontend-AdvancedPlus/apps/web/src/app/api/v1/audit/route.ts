import { NextResponse, type NextRequest } from "next/server";
import { loadDb, saveDb, makeId } from "@/server/store";
import { getRole } from "@/server/rbac";

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const db = loadDb();
  db.audit_logs.push({
    id: makeId("AUDIT"),
    at: new Date().toISOString(),
    role: getRole(req),
    actor_id: req.headers.get("x-actor-id") || "unknown",
    org_id: req.headers.get("x-org-id") || "default-org",
    action: body.action || "UNKNOWN",
    payload: body.payload || null
  });
  saveDb(db);
  return NextResponse.json({ ok: true });
}
