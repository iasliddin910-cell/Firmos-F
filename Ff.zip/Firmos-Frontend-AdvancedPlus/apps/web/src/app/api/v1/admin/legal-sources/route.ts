import { NextResponse, type NextRequest } from "next/server";
import { loadDb, saveDb, makeId } from "@/server/store";
import { requireRole } from "@/server/rbac";

export async function GET(req: NextRequest) {
  const auth = requireRole(req, "ADMIN");
  if (!auth.ok) return NextResponse.json({ error: "forbidden", role: auth.role }, { status: 403 });

  const db = loadDb();
  return NextResponse.json({ items: db.legal_sources });
}

export async function POST(req: NextRequest) {
  const auth = requireRole(req, "ADMIN");
  if (!auth.ok) return NextResponse.json({ error: "forbidden", role: auth.role }, { status: 403 });

  const body = await req.json().catch(() => ({}));
  const db = loadDb();

  const item = {
    id: makeId("LS"),
    jurisdiction: body.jurisdiction || "UZ",
    source_type: body.source_type || "TAX_CODE",
    title: body.title || "Untitled",
    reference_code: body.reference_code || "UNSPEC",
    effective_from: body.effective_from || "2025-01-01",
    effective_to: body.effective_to || null,
    text_content: body.text_content || "",
    metadata_json: body.metadata_json || {},
    created_by: req.headers.get("x-actor-id") || "unknown",
    created_at: new Date().toISOString()
  };

  db.legal_sources.push(item);
  saveDb(db);

  return NextResponse.json({ ok: true, id: item.id });
}
