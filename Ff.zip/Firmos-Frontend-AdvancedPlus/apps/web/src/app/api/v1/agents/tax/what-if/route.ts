import { NextResponse, type NextRequest } from "next/server";
import { loadDb } from "@/server/store";
import { requireRole } from "@/server/rbac";

export async function POST(req: NextRequest) {
  const auth = requireRole(req, "OPERATOR");
  if (!auth.ok) return NextResponse.json({ error: "forbidden", role: auth.role }, { status: 403 });

  const body = await req.json().catch(() => ({}));
  const scenario = body.scenario ?? {};

  const db = loadDb();
  const src = db.legal_sources.find((s) => s.reference_code === "WHATIF_RULES");

  if (!src) {
    return NextResponse.json({
      status: "BASIS_MISSING",
      scenario,
      result: null,
      note: "What-if hisoblash uchun rasmiy qoidalar (WHATIF_RULES) registry’da yo‘q. Natija hisoblanmadi.",
      assumptions: ["No official basis configured"],
      citations: []
    });
  }

  return NextResponse.json({
    status: "OK",
    scenario,
    result: { estimated_tax_change: 0, explanation: "Demo: rule engine keyin backend’da kengayadi." },
    assumptions: ["Demo calculation"],
    citations: [{ legal_source_id: src.id, citation_label: `${src.source_type}:${src.reference_code}` }]
  });
}
