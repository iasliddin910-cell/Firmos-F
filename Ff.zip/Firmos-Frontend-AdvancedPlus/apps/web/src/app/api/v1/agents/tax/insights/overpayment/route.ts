import { NextResponse, type NextRequest } from "next/server";
import { loadDb } from "@/server/store";
import { requireRole } from "@/server/rbac";

export async function GET(req: NextRequest) {
  const auth = requireRole(req, "ANALYST");
  if (!auth.ok) return NextResponse.json({ error: "forbidden", role: auth.role }, { status: 403 });

  const db = loadDb();
  const src = db.legal_sources.find((s) => s.reference_code === "EXPECTED_TAX_FORMULA");

  if (!src) {
    return NextResponse.json({
      status: "BASIS_MISSING",
      holat: "To‘lovlar mavjud (demo), lekin kutilgan soliq formulasi registry’da yo‘q.",
      qonuniy_asos: "Expected tax hisoblash uchun rasmiy formula manbasi kerak.",
      oqibat_xavf: "Ortiqcha to‘lovni aniqlash uchun registry’ga rasmiy qoida kiriting va buxgalter bilan tasdiqlang.",
      citations: []
    });
  }

  return NextResponse.json({
    status: "OK",
    holat: "Actual paid: 120 000 000 so‘m (demo)\nExpected: 108 000 000 so‘m (demo)",
    qonuniy_asos: `Manba: ${src.title} (${src.reference_code})`,
    oqibat_xavf: "Ortiqcha to‘lov: 12 000 000 so‘m (demo). Qaytarish/offset bo‘yicha buxgalter bilan tasdiqlang.",
    citations: [{ legal_source_id: src.id, citation_label: `${src.source_type}:${src.reference_code}` }]
  });
}
