import { NextResponse, type NextRequest } from "next/server";
import { loadDb } from "@/server/store";
import { requireRole } from "@/server/rbac";

export async function GET(req: NextRequest) {
  const auth = requireRole(req, "ANALYST");
  if (!auth.ok) return NextResponse.json({ error: "forbidden", role: auth.role }, { status: 403 });

  const db = loadDb();
  const src = db.legal_sources.find((s) => s.reference_code === "PENALTY_FORMULA");

  if (!src) {
    return NextResponse.json({
      status: "BASIS_MISSING",
      holat: "Hujjatlarda (demo) 1 ta kechikish flag bor. Ammo jarima formulasi registry’da yo‘q.",
      qonuniy_asos: "Jarima miqdorini hisoblash uchun rasmiy formula manbasi registry’da kiritilmagan.",
      oqibat_xavf: "Kechikish jarimaga olib kelishi mumkin. Jarimani baholash uchun rasmiy asos qo‘shilsin va buxgalter bilan tasdiqlang.",
      citations: []
    });
  }

  const base = src.metadata_json?.base_amount ?? 0;
  const perDay = src.metadata_json?.per_day ?? 0;
  const daysLate = 5;
  const estimate = base + perDay * daysLate;

  return NextResponse.json({
    status: "OK",
    holat: `Kechikish: ${daysLate} kun (demo).`,
    qonuniy_asos: `Manba: ${src.title} (${src.reference_code}).`,
    oqibat_xavf: `Taxminiy jarima: ${estimate} (demo). Buxgalter bilan tasdiqlang.`,
    citations: [{ legal_source_id: src.id, citation_label: `${src.source_type}:${src.reference_code}` }]
  });
}
