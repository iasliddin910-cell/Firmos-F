import { NextResponse } from "next/server";
import { loadDb } from "@/server/store";

export async function GET() {
  const db = loadDb();
  return NextResponse.json({ items: db.signals });
}
