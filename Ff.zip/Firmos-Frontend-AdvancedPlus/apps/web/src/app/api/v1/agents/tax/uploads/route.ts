import { NextResponse, type NextRequest } from "next/server";
import { loadDb, saveDb, makeId } from "@/server/store";
import { requireRole } from "@/server/rbac";
import path from "node:path";
import fs from "node:fs";

const DOC_DIR = path.join(process.cwd(), ".local-data", "tax-docs");

function ensureDir() {
  if (!fs.existsSync(DOC_DIR)) fs.mkdirSync(DOC_DIR, { recursive: true });
}

function extOf(name: string) {
  const m = name.toLowerCase().match(/\.([a-z0-9]+)$/);
  return m ? m[1] : "";
}

function parseCsv(text: string) {
  const lines = text.split(/\r?\n/).filter(Boolean);
  if (lines.length === 0) return { rows: [] };
  const header = lines[0].split(",").map((s) => s.trim());
  const rows = lines.slice(1, 101).map((ln) => {
    const cols = ln.split(",").map((s) => s.trim());
    const obj: any = {};
    header.forEach((h, i) => (obj[h || `col_${i}`] = cols[i] ?? ""));
    return obj;
  });
  return { header, rows };
}

export async function POST(req: NextRequest) {
  const auth = requireRole(req, "OPERATOR");
  if (!auth.ok) return NextResponse.json({ error: "forbidden", role: auth.role }, { status: 403 });

  const form = await req.formData();
  const file = form.get("file");
  if (!file || typeof file === "string") {
    return NextResponse.json({ error: "file_missing" }, { status: 400 });
  }

  // Next provides File
  const f = file as File;
  const filename = f.name || "upload.bin";
  const ext = extOf(filename);
  const id = makeId("TAXDOC");

  ensureDir();
  const storage_path = path.join(DOC_DIR, `${id}_${filename}`);
  const buf = Buffer.from(await f.arrayBuffer());
  fs.writeFileSync(storage_path, buf);

  let parse_status: "PARSED" | "NEEDS_MANUAL" | "FAILED" = "NEEDS_MANUAL";
  let parsed_json: any = null;

  try {
    if (ext === "csv") {
      const text = buf.toString("utf-8");
      parsed_json = parseCsv(text);
      parse_status = "PARSED";
    } else if (ext === "xlsx") {
      // XLSX parsing (deterministic) — extracts first sheet to JSON
      const xlsxMod: any = await import("xlsx");
      const xlsx: any = xlsxMod.default ?? xlsxMod;
      const wb = xlsx.read(buf, { type: "buffer" });
      const first = wb.SheetNames[0];
      const sheet = wb.Sheets[first];
      const json = xlsx.utils.sheet_to_json(sheet, { defval: "" });
      parsed_json = { sheet: first, rows: json };
      parse_status = "PARSED";
    } else if (ext === "pdf") {
      // No OCR. Best-effort structured text extraction.
      const pdfMod: any = await import("pdf-parse");
      const pdfParse: any = pdfMod.default ?? pdfMod;
      const out = await pdfParse(buf);
      const text = String(out?.text || "").trim();
      if (text.length > 50) {
        parsed_json = { extracted_text_preview: text.slice(0, 2000) };
        parse_status = "PARSED";
      } else {
        parse_status = "NEEDS_MANUAL";
      }
    } else {
      parse_status = "NEEDS_MANUAL";
    }
  } catch {
    parse_status = "NEEDS_MANUAL";
  }

  const db = loadDb();
  db.tax_documents.push({
    id,
    filename,
    file_type: ext || "unknown",
    storage_path,
    uploaded_by: req.headers.get("x-actor-id") || "unknown",
    uploaded_at: new Date().toISOString(),
    parsed_json,
    parse_status
  });
  saveDb(db);

  return NextResponse.json({ ok: true, id, parse_status });
}
