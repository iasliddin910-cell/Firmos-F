import { NextResponse, type NextRequest } from "next/server";
import { loadDb, saveDb, makeId } from "@/server/store";
import { requireRole } from "@/server/rbac";

export async function GET() {
  const db = loadDb();
  return NextResponse.json({ decisions: db.company_brain.decisions });
}

export async function POST(req: NextRequest) {
  const auth = requireRole(req, "OPERATOR");
  if (!auth.ok) return NextResponse.json({ error: "forbidden", role: auth.role }, { status: 403 });

  const body = await req.json().catch(() => ({}));
  const db = loadDb();

  const proposal = body.proposal ?? {};
  const title = String(body.title || "Untitled decision");

  const conflicts = db.company_brain.conflicts.filter((c) => {
    // demo: if proposal includes discount >= 50, mark as conflict with compliance
    try {
      const t = JSON.stringify(proposal).toLowerCase();
      return t.includes("discount") || t.includes("chegirma") || t.includes("vat") || c.severity === "HIGH";
    } catch {
      return c.severity === "HIGH";
    }
  });

  db.company_brain.decisions.push({
    id: makeId("DEC"),
    title,
    proposal,
    created_at: new Date().toISOString(),
    stage: conflicts.length ? "BLOCKED_CONFLICT" : "SIMULATION",
    conflicts
  });

  saveDb(db);
  return NextResponse.json({ ok: true });
}
