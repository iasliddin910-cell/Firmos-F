import { NextResponse, type NextRequest } from "next/server";
import { loadDb } from "@/server/store";
import { requireRole } from "@/server/rbac";

export async function GET(req: NextRequest) {
  const auth = requireRole(req, "ANALYST");
  if (!auth.ok) return NextResponse.json({ error: "forbidden", role: auth.role }, { status: 403 });

  const db = loadDb();
  const src = db.legal_sources.find((s) => s.reference_code === "DEDUCTIBILITY_RULES");

  if (!src) {
    return NextResponse.json({
      status: "BASIS_MISSING",
      holat: "Xarajatlar (demo) bor, lekin deductibility qoidalari registry’da yo‘q.",
      qonuniy_asos: "Har bir non-deductible sabab rasmiy manba bilan bog‘lanishi shart.",
      oqibat_xavf: "Noto‘g‘ri deduct qilish soliq riskini oshiradi. Registry’ga rasmiy qoida qo‘shing va buxgalter bilan tasdiqlang.",
      citations: []
    });
  }

  return NextResponse.json({
    status: "OK",
    holat: "3 ta xarajat tekshirildi (demo). 1 tasida invoice yo‘q.",
    qonuniy_asos: `Manba: ${src.title} (${src.reference_code})`,
    oqibat_xavf: "Invoice bo‘lmasa deduct qilinmasligi mumkin. Soliq bazasi oshadi. Buxgalter bilan tasdiqlang.",
    citations: [{ legal_source_id: src.id, citation_label: `${src.source_type}:${src.reference_code}` }]
  });
}
