import { NextResponse, type NextRequest } from "next/server";
import { requireRole } from "@/server/rbac";
import { loadDb, saveDb } from "@/server/store";

export async function POST(req: NextRequest) {
  const auth = requireRole(req, "ADMIN");
  if (!auth.ok) return NextResponse.json({ error: "forbidden", role: auth.role }, { status: 403 });

  const body = await req.json().catch(() => ({}));
  const connector = String(body.connector || "unknown");
  const config = body.config || {};

  const ok = Object.keys(config).length > 0 && Object.values(config).some((v) => String(v).trim().length > 0);

  const db = loadDb();
  db.integrations[connector] = { config, status: ok ? "OK" : "FAIL", tested_at: new Date().toISOString() };
  saveDb(db);

  return NextResponse.json({ status: ok ? "OK" : "FAIL" });
}
