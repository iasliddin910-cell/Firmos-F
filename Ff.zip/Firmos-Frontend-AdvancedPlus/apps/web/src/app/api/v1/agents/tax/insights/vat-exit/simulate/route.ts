import { NextResponse, type NextRequest } from "next/server";
import { loadDb } from "@/server/store";
import { requireRole } from "@/server/rbac";

export async function POST(req: NextRequest) {
  const auth = requireRole(req, "OPERATOR");
  if (!auth.ok) return NextResponse.json({ error: "forbidden", role: auth.role }, { status: 403 });

  const body = await req.json().catch(() => ({}));
  const monthly = Number(body.monthly_turnover ?? 0);

  const db = loadDb();
  const src = db.legal_sources.find((s) => s.reference_code === "VAT_EXIT_RULES");

  if (!src) {
    return NextResponse.json({
      status: "BASIS_MISSING",
      note: "VAT exit simulation uchun rasmiy qoidalar registry’da yo‘q.",
      assumptions: ["No official basis configured"],
      citations: []
    });
  }

  const vatRate = Number(src.metadata_json?.vat_rate ?? 0.12);
  const altRate = Number(src.metadata_json?.alt_tax_rate ?? 0.04);

  const vat = monthly * vatRate;
  const alt = monthly * altRate;

  return NextResponse.json({
    status: "OK",
    monthly_turnover: monthly,
    vat_estimate: vat,
    alt_estimate: alt,
    delta: alt - vat,
    side_effects: ["Invoice format changes", "Counterparty VAT credit impact", "Reporting schedule changes"],
    citations: [{ legal_source_id: src.id, citation_label: `${src.source_type}:${src.reference_code}` }],
    note: "Simulation only. Confirm with accountant."
  });
}
