import { NextResponse, type NextRequest } from "next/server";
import { loadDb } from "@/server/store";
import { requireRole } from "@/server/rbac";

export async function GET(req: NextRequest) {
  const auth = requireRole(req, "ANALYST");
  if (!auth.ok) return NextResponse.json({ error: "forbidden", role: auth.role }, { status: 403 });

  const db = loadDb();
  const src = db.legal_sources.find((s) => s.reference_code === "REGIME_RULES") || db.legal_sources[0];

  if (!src) {
    return NextResponse.json({
      status: "BASIS_MISSING",
      holat: "Rejimni tekshirish uchun legal_sources registry’da rasmiy qoida yo‘q.",
      qonuniy_asos: "Rasmiy manba registry’da mavjud emas.",
      oqibat_xavf: "Noto‘g‘ri rejim tanlansa jarima yoki ortiqcha soliq xavfi bor. Buxgalter bilan tasdiqlang.",
      citations: []
    });
  }

  const threshold = src.metadata_json?.simplified_regime_turnover_threshold ?? null;
  const holatLines = [
    "Hozirgi rejim: (demo) Soddalashtirilgan",
    "Aylanma: (demo) 1.2 mlrd so‘m / yil",
    threshold ? `Registry threshold: ${threshold}` : "Registry threshold: (missing in metadata_json)"
  ];

  const ok = threshold ? 1200000000 <= threshold : false;

  return NextResponse.json({
    status: threshold ? "OK" : "PARTIAL",
    holat: holatLines.join("\n"),
    qonuniy_asos: `Manba: ${src.title} (${src.reference_code}).\nEslatma: faqat rasmiy manbalar.`,
    oqibat_xavf: ok
      ? "Ko‘rsatkichlar threshold ichida (demo). Baribir buxgalter bilan tasdiqlang."
      : "Threshold bo‘yicha ehtimoliy mos kelmaslik bor yoki qoida metadata’da yo‘q. Buxgalter bilan tasdiqlang.",
    citations: [
      {
        legal_source_id: src.id,
        citation_label: `${src.source_type}:${src.reference_code}`,
        article: src.reference_code
      }
    ]
  });
}
