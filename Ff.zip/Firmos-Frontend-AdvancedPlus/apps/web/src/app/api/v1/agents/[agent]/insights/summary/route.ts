import { NextResponse, type NextRequest } from "next/server";

function nowISO() {
  return new Date().toISOString();
}

function salesSummary() {
  return {
    kpis: { loss_24h: 24500000, funnel_loss: 51200000, conv_7d: 2.8 },
    funnel: [
      { stage: "Landing → Product", drop_users: 1800, potential_loss: 12000000 },
      { stage: "Product → Checkout", drop_users: 950, potential_loss: 24000000 },
      { stage: "Checkout → Payment", drop_users: 410, potential_loss: 15200000 }
    ],
    channel: [
      { channel: "Telegram", orders: 120, profit: 6100000, risk: "MED" },
      { channel: "Website", orders: 340, profit: 18200000, risk: "LOW" },
      { channel: "Marketplace", orders: 90, profit: 2400000, risk: "HIGH" }
    ],
    complaints: [
      { topic: "Yetkazib berish kechikdi", linked_to: "Warehouse / courier", count: 31, estimated_loss: 3800000, impact: "MED" },
      { topic: "To‘lovda xato", linked_to: "Payment provider", count: 9, estimated_loss: 2100000, impact: "MED" }
    ],
    opportunities: [
      { id: "OP1", title: "Checkout soddalashtirish", reason: "Drop yuqori", expected_uplift: "+0.4% conv" },
      { id: "OP2", title: "7-10pm push (low complaints)", reason: "Eng sokin vaqt", expected_uplift: "+12% orders" }
    ],
    segments: [
      { segment: "Repeat buyers", arpu: 420000, complaints: 2, note: "Eng barqaror foyda" },
      { segment: "First-time", arpu: 190000, complaints: 19, note: "Onboarding yaxshilash kerak" }
    ],
    time_windows: [
      { hour: 9, conversion: 2.1, complaints: 4 },
      { hour: 12, conversion: 2.7, complaints: 6 },
      { hour: 19, conversion: 3.4, complaints: 1 },
      { hour: 22, conversion: 3.1, complaints: 0 }
    ],
    generated_at: nowISO()
  };
}

function marketingSummary() {
  return {
    kpis: { roi_7d: 34, harmful_campaigns: 2, ad_fatigue: 58 },
    campaigns: [
      { id: "C1", name: "Meta - Broad", spend: 12000000, profit: 6200000, status: "HARMFUL" },
      { id: "C2", name: "Google - Search", spend: 8000000, profit: 17400000, status: "OK" },
      { id: "C3", name: "TikTok - Spark", spend: 6000000, profit: 5200000, status: "WATCH" }
    ],
    fake_leads: [
      { id: "F1", source: "Meta", seconds: 7, pages: 1, reason: "No scroll, no add-to-cart" },
      { id: "F2", source: "TikTok", seconds: 9, pages: 1, reason: "Bounce + repeat pattern" }
    ],
    landing: [
      { metric: "Bounce rate", value: "62%", note: "Hero blok yuklanishi sekin" },
      { metric: "Checkout drop", value: "41%", note: "Too many fields" },
      { metric: "Scroll depth", value: "28%", note: "Value prop pastda" }
    ],
    audiences: [
      { segment: "High intent (search)", share: 41, channel: "Google", note: "ARPU yuqori" },
      { segment: "Warm retarget", share: 22, channel: "Meta", note: "Conv stabil" },
      { segment: "Cold short-video", share: 37, channel: "TikTok", note: "Fake lead risk" }
    ],
    budget_moves: [
      { id: "BM1", from: "Meta - Broad", to: "Google - Search", amount: 4000000, expected_profit: 7200000 }
    ],
    fatigue: [
      { ad: "Creative A", ctr: 0.8, conv: 1.2, note: "Yangilash kerak" },
      { ad: "Creative B", ctr: 1.1, conv: 2.0, note: "OK" },
      { ad: "Creative C", ctr: 0.6, conv: 0.9, note: "Stop / replace" }
    ],
    generated_at: nowISO()
  };
}

function cashflowSummary() {
  return {
    kpis: { runway_days: 53, monthly_burn: 156000000, daily_stress: "HIGH" },
    expense_drain: [
      { category: "Ads (low ROI)", monthly: 52000000, return: 28000000, note: "Harmful kampaniya bor" },
      { category: "Logistics", monthly: 24000000, return: 0, note: "Kechikish shikoyatni oshiryapti" }
    ],
    hidden_leaks: [
      { id: "L1", title: "Unused SaaS subscriptions", freq: "monthly", amount: 2400000, yearly: 28800000 },
      { id: "L2", title: "Duplicate courier contracts", freq: "weekly", amount: 850000, yearly: 44200000 }
    ],
    forward_risk: [
      { days: 30, status: "MED", note: "Marketing spend optimizatsiya kerak" },
      { days: 60, status: "HIGH", note: "Runway qisqa, tezkor choralar" },
      { days: 90, status: "HIGH", note: "Cash gap ehtimoli yuqori" }
    ],
    generated_at: nowISO()
  };
}

function complianceSummary() {
  return {
    kpis: { risk_score: 62, risk_level: "MED", deadlines: 3, law_changes: 2 },
    law_changes: [
      { id: "LC1", title: "Yangi qaror: hisobot formati yangilandi (demo)", effective_from: "2026-02-01", note: "Lex.uz orqali tekshiring", risk: "MED" },
      { id: "LC2", title: "Rasmiy izoh: e-invoice talablari (demo)", effective_from: "2026-01-15", note: "Rasmiy izoh matni registry’da", risk: "LOW" }
    ],
    deadlines: [
      { item: "License renewal", days_left: 14, impact: "Jarima + faoliyat cheklanishi" },
      { item: "Contract re-sign", days_left: 7, impact: "Ta’minot uzilishi" },
      { item: "Annual policy update", days_left: 30, impact: "Risk oshishi" }
    ],
    cross_checks: [
      { id: "X1", proposal: "60% discount campaign", note: "Consumer law / ad law check required", status: "WARN" },
      { id: "X2", proposal: "VAT exit plan", note: "Tax basis required in registry", status: "WARN" }
    ],
    generated_at: nowISO()
  };
}

function cyberSummary() {
  return {
    kpis: { risk_score: 78, risk_level: "MED", infra_health: 41, downtime_loss_today: 7200000 },
    anomalous_logins: [
      { id: "A1", time: nowISO(), ip: "203.0.113.9", geo: "Unknown", reason: "Unusual time + new IP" },
      { id: "A2", time: nowISO(), ip: "198.51.100.13", geo: "RU", reason: "Multiple failed attempts" }
    ],
    bot_events: [
      { id: "B1", title: "Spike in checkout requests", note: "Rate-limit needed" },
      { id: "B2", title: "Brute-force attempts", note: "WAF rules recommended" }
    ],
    data_leaks: [
      { id: "D1", title: "Large export outside business hours", note: "Audit + review access" }
    ],
    generated_at: nowISO()
  };
}

export async function GET(req: NextRequest, { params }: { params: { agent: string } }) {
  const agent = (params.agent || "").toLowerCase();

  if (agent === "sales") return NextResponse.json(salesSummary());
  if (agent === "marketing") return NextResponse.json(marketingSummary());
  if (agent === "cashflow") return NextResponse.json(cashflowSummary());
  if (agent === "compliance") return NextResponse.json(complianceSummary());
  if (agent === "cyber") return NextResponse.json(cyberSummary());

  return NextResponse.json({ error: "unknown agent" }, { status: 404 });
}
