import { NextResponse, type NextRequest } from "next/server";
import { loadDb } from "@/server/store";
import { requireRole } from "@/server/rbac";

export async function POST(req: NextRequest) {
  const auth = requireRole(req, "ANALYST");
  if (!auth.ok) return NextResponse.json({ error: "forbidden", role: auth.role }, { status: 403 });

  const body = await req.json().catch(() => ({}));
  const topic = String(body.topic || "QQS_REPORT");

  const db = loadDb();
  const tpl = db.tax_guidance_templates[topic] || db.tax_guidance_templates["QQS_REPORT"];

  return NextResponse.json({
    topic,
    steps: tpl?.steps || [],
    warnings: (tpl?.warnings || []).concat([
      "Bu guidance-only. Login/imzo/yuborish agent tomonidan bajarilmaydi."
    ])
  });
}
