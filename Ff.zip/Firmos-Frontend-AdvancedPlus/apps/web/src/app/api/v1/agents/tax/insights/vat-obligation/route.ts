import { NextResponse, type NextRequest } from "next/server";
import { loadDb } from "@/server/store";
import { requireRole } from "@/server/rbac";

export async function GET(req: NextRequest) {
  const auth = requireRole(req, "ANALYST");
  if (!auth.ok) return NextResponse.json({ error: "forbidden", role: auth.role }, { status: 403 });

  const db = loadDb();
  const src = db.legal_sources.find((s) => s.reference_code === "VAT_THRESHOLD") || db.legal_sources[0];

  if (!src) {
    return NextResponse.json({
      status: "BASIS_MISSING",
      holat: "VAT threshold topilmadi.",
      qonuniy_asos: "Legal sources registry bo‘sh.",
      oqibat_xavf: "QQS majburiyati aniqlanmaydi. Rasmiy manba qo‘shing va buxgalter bilan tasdiqlang.",
      citations: []
    });
  }

  const threshold = Number(src.metadata_json?.threshold_12m_turnover ?? 0) || 0;
  if (!threshold) {
    return NextResponse.json({
      status: "PARTIAL",
      holat: "VAT threshold metadata_json’da yo‘q.",
      qonuniy_asos: `Manba: ${src.title} (${src.reference_code})`,
      oqibat_xavf: "Threshold bo‘lmasa majburiyatni hisoblab bo‘lmaydi. Registry’ni to‘ldiring.",
      citations: [{ legal_source_id: src.id, citation_label: `${src.source_type}:${src.reference_code}` }]
    });
  }

  const turnover12m = 920000000; // demo
  const remaining = threshold - turnover12m;
  const monthsTo = remaining <= 0 ? 0 : Math.ceil((remaining / (turnover12m / 12)) || 0);

  return NextResponse.json({
    status: "OK",
    holat: `Oxirgi 12 oy aylanma: ${turnover12m} so‘m (demo)\nThreshold: ${threshold} so‘m\nQolgan: ${remaining} so‘m`,
    qonuniy_asos: `Manba: ${src.title} (${src.reference_code})`,
    oqibat_xavf: remaining <= 0
      ? "Threshold oshgan bo‘lishi mumkin — QQS majburiyati bo‘yicha zudlik bilan buxgalter bilan tasdiqlang."
      : `Threshold’ga yaqin. Taxminiy ${monthsTo} oy ichida majburiy bo‘lishi mumkin. Buxgalter bilan tasdiqlang.`,
    citations: [{ legal_source_id: src.id, citation_label: `${src.source_type}:${src.reference_code}` }]
  });
}
