import { NextResponse, type NextRequest } from "next/server";
import { requireRole } from "@/server/rbac";

export async function POST(req: NextRequest) {
  const auth = requireRole(req, "ANALYST");
  if (!auth.ok) return NextResponse.json({ error: "forbidden", role: auth.role }, { status: 403 });

  const body = await req.json().catch(() => ({}));
  const text = String(body.text || "").toLowerCase();

  const flags: any[] = [];
  if (text.includes("jarima") || text.includes("penalty")) flags.push({ type: "PENALTY_CLAUSE", severity: "MED", note: "Jarima bandi bor. Limit/foizni tekshiring." });
  if (text.includes("bir tomonlama") || text.includes("unilateral")) flags.push({ type: "UNILATERAL_TERMINATION", severity: "HIGH", note: "Bir tomonlama bekor qilish riski." });
  if (text.includes("maxfiy") || text.includes("confidential")) flags.push({ type: "CONFIDENTIALITY", severity: "LOW", note: "Maxfiylik bandi bor." });

  return NextResponse.json({
    status: flags.some((f) => f.severity === "HIGH") ? "WARN" : "OK",
    flags
  });
}
