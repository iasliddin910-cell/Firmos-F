import { NextResponse, type NextRequest } from "next/server";
import { loadDb } from "@/server/store";
import { requireRole } from "@/server/rbac";

export async function GET(req: NextRequest) {
  const auth = requireRole(req, "ANALYST");
  if (!auth.ok) return NextResponse.json({ error: "forbidden", role: auth.role }, { status: 403 });

  const db = loadDb();
  return NextResponse.json({ documents: db.tax_documents });
}
